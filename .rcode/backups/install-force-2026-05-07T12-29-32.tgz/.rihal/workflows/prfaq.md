# Workflow: rihal-prfaq

<purpose>
Working Backwards PRFAQ challenge. Stress-test a product concept by writing the press release before building it. Produces a battle-hardened PRFAQ document + PRD distillate. Delegates to the rihal-prfaq skill for the full interview and generation protocol.
</purpose>

@rihal/skills/actions/1-analysis/rihal-prfaq/SKILL.md
